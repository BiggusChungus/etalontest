// Файл для сборки всех скриптов

// @prepros-append libs/lazyload.js
// @prepros-append animations.js
// @prepros-append app.js
